package com.example.demo.service;

import com.example.demo.entity.Patient;
import com.example.demo.error.PatientNotFoundException;

public interface PatientService {

	Patient fetchPatientById(Integer aid) throws PatientNotFoundException;


}
