package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.Patient;
import com.example.demo.error.PatientNotFoundException;
import com.example.demo.service.ReceptionistService;

@RestController
public class ReceptionistController {
	
	@Autowired
	ReceptionistService receptionistService;

/*
 * Receptionist Can 
 *		See All Patient Details
 * 		Add Patient Details
 * 		Delete All Patient 
 * 		Update Patient Details
 */
	
//***********************GET ALL PATIENT**********************
	
		@GetMapping("/AllPatient/")
		public List<Patient> fetchPatient()
		{
			return receptionistService.fetchPatientList();
		}

	
//************************ADD PATIENT*************************
		
		@PostMapping("/AddPatient/")
		public String savePatient(@RequestBody Patient patient)
		{
			receptionistService.savePatient(patient);
			return "patient record inserted successfully";
		}
		
//************************DELETE PATIENT**********************
		
		@DeleteMapping("/RemovePatient/{id}/")
		public String deletePatientById(@PathVariable("id") Integer pid) throws PatientNotFoundException
		{
			receptionistService.deletePatientById(pid);
			return "Patient Cancelled the Appointment";
		}

//************************UPDATE PATIENT**********************

		@PutMapping("/UpdatePatient/{id}/")
		public Patient updatePatient(@PathVariable("id") Integer pid, @RequestBody Patient patient) throws PatientNotFoundException
		{
			return receptionistService.updatePatient(pid,patient);
		}
		

//*******************GET PATIENT DETAILS BY NAME*************
		
		@GetMapping("/PatientByName/{name}/")
		public Patient fetchPatientByPname(@PathVariable("name")String pname ) throws PatientNotFoundException 
			{
				return receptionistService.fetchPatientByPname(pname);
						
			}


}
