package com.example.demo.entity;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name = "Doctor_Details")
public class Doctor {
	@Id
	@NotNull(message = "Doctor id cannot be Null")
	private int did;
	@Column(name = "DoctorName")
	private String name;
	@Column(name = "DoctorMail",unique=true)
	@Email
	private String emailid;
	@Column(name = "MobileNumber")
	@Length(min = 10, max = 13, message = "Mobile number cannot be less than 10 Character")
	private String contactno;
	@Column(name = "Designation")
	@NotBlank(message = "Please fill the Designation field")
	private String designation;
	@Column(name = "Speciality")
	@NotBlank(message = "Speciality field cannot be Empty")
	private String speciality;
	@Column(name = "VisitingHours")
	private String visitinghours;
	
	@OneToMany(targetEntity = Patient.class,cascade = CascadeType.ALL)
	@JoinColumn(name="doctor_id")
	private List<Patient> patient;

	public Doctor() {
		super();
	}

	public Doctor(int did, String name, @Email String emailid,
			@Length(min = 10, max = 13, message = "Mobile number cannot be less than 10 Character") String contactno,
			@NotBlank(message = "Please fill the Designation field") String designation,
			@NotBlank(message = "Speciality field is empty") String speciality, String visitinghours,
			List<Patient> patient) {
		super();
		this.did = did;
		this.name = name;
		this.emailid = emailid;
		this.contactno = contactno;
		this.designation = designation;
		this.speciality = speciality;
		this.visitinghours = visitinghours;
		this.patient = patient;
	}

	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	public String getVisitinghours() {
		return visitinghours;
	}

	public void setVisitinghours(String visitinghours) {
		this.visitinghours = visitinghours;
	}

	public List<Patient> getPatient() {
		return patient;
	}

	public void setPatient(List<Patient> patient) {
		this.patient = patient;
	}

	@Override
	public String toString() {
		return "Doctor [did=" + did + ", name=" + name + ", emailid=" + emailid + ", contactno=" + contactno
				+ ", designation=" + designation + ", speciality=" + speciality + ", visitinghours=" + visitinghours
				+ ", patient=" + patient + "]";
	}
	
	
	
}
